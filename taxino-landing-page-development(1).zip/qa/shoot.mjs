import { chromium } from "playwright";
import { createServer } from "http";
import { readFile } from "fs/promises";
import { extname, join } from "path";

const root = "dist";
const mime = { ".html": "text/html", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".txt": "text/plain", ".xml": "application/xml" };

const server = createServer(async (req, res) => {
  try {
    let p = req.url.split("?")[0];
    if (p === "/") p = "/index.html";
    const buf = await readFile(join(root, p));
    res.writeHead(200, { "content-type": mime[extname(p)] || "application/octet-stream" });
    res.end(buf);
  } catch {
    res.writeHead(404);
    res.end("nf");
  }
});
await new Promise((r) => server.listen(4173, r));

const browser = await chromium.launch();
const errors = [];

async function snap(width, height, name, actions) {
  const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1 });
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`[${name}] ${m.text().slice(0, 200)}`);
  });
  page.on("pageerror", (e) => errors.push(`[${name}] PAGEERROR ${String(e).slice(0, 200)}`));
  await page.goto("http://localhost:4173/", { waitUntil: "networkidle" });
  await page.waitForTimeout(4200); // let the intro finish
  for (const [sel, file, extra] of actions) {
    if (sel) {
      await page.evaluate((s) => document.querySelector(s)?.scrollIntoView({ block: "start" }), sel);
      await page.waitForTimeout(1400);
    }
    if (extra) await page.evaluate(extra);
    await page.waitForTimeout(700);
    await page.screenshot({ path: `qa/${file}` });
    console.log("shot:", file);
  }
  await page.close();
}

await snap(1440, 900, "desktop", [
  [null, "d1-hero.png"],
  ["#features", "d2-features.png"],
  ["#showcase", "d3-showcase.png"],
  ["#workflow", "d4-workflow.png"],
  ["#pricing", "d5-pricing.png"],
  ["#faq", "d6-faq.png"],
  ["#contact", "d7-cta.png"],
  ["footer", "d8-footer.png"],
]);

await snap(390, 844, "mobile", [
  [null, "m1-hero.png"],
  ["#features", "m2-features.png"],
  ["#showcase", "m3-showcase.png"],
  ["#contact", "m4-cta.png"],
]);

console.log(errors.length ? "CONSOLE ERRORS:\n" + errors.join("\n") : "NO CONSOLE ERRORS");
await browser.close();
server.close();
