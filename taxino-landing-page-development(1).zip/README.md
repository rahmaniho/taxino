# تاکسینو — لندینگ رسمی محصول | TAXINO Landing

صفحهٔ فرود سینمایی و مجزا برای محصول **تاکسینو | Taxino** (نرم‌افزار هوشمند مدیریت دفاتر تاکسی تلفنی — Powered by KarenSoft). این پروژه از اپلیکیشن اصلی (`rahmaniho/taxi`) کاملاً مستقل است و هیچ‌گونه تغییری در آن ایجاد نکرده است.

## معماری

```
index.html              RTL + SEO: متا‌های فارسی، OG/Twitter، JSON-LD (Organization, SoftwareApplication, FAQPage)
public/
  assets/brand/         لوگوی واقعی تاکسینو (از مخزن محصول)
  assets/img/           تصاویر سینمایی (شهر شب + خودرو)
  robots.txt, sitemap.xml
src/
  data/content.ts       تنها منبع محتوای فارسی — نگهداری مستقل از کد
  lib/anim.ts           GSAP + ScrollTrigger، هوک reveal، احترام به prefers-reduced-motion
  components/           Nav · Hero · TrustStrip · Challenges · Features · Showcase ·
                        Workflow · Compare · Benefits · Pricing · Faq · FinalCta · Footer
qa/shoot.mjs            تست دیداری خودکار با Playwright (دسکتاپ ۱۴۴۰ + موبایل ۳۹۰)
```

## دستورها

```bash
npm install          # نصب
npm run dev          # توسعه محلی
npm run build        # بیلد پروداکشن → dist/ (خروجی تک‌فایل)
npm run preview      # پیش‌نمایش بیلد
node qa/shoot.mjs    # QA دیداری + بررسی کنسول روی dist/
```

## اهداف و واقعیت‌ها (Verified)

- **تمام قابلیت‌های معرفی‌شده از سورس واقعی محصول (v1.6.0 / ROADMAP) استخراج شده‌اند** — ثبت سفر، صف انتظار با هشدار، دیسپچ نوبتی، حسابداری ۸ بخشه با تاریخ شمسی، قفل PIN و نقش‌ها، پشتیبان‌گیری رمزنگاری‌شده، همگام‌سازی محلی/فایلی، حالت فقط‌خواندنی پس از انقضای اشتراک.
- داده‌های نمایشی صریحاً با برچسب «دادهٔ نمایشی» مشخص شده‌اند.
- قیمت‌گذاری عمداً «استعلام از کارشناسان» است (بدون قیمت ساختگی).
- مقصد همهٔ CTAها واقعی است: `taxi.karen-soft.ir` و مخزن/Issues گیت‌هاب.
- بدون شمارهٔ تماس/ایمیل/نشانی ساختگی.

## دسترس‌پذیری و پرفورمنس

- لندمارک‌های معنایی، اسکیپ‌لینک «پرش به محتوا»، فوکوس مرئی طلایی، `aria-expanded`/`aria-selected`، کنتراست بالا.
- احترام کامل به `prefers-reduced-motion` (تمام انیمیشن‌ها غیرفعال می‌شوند).
- پنل‌های شناور و پارالاکس ماوس فقط روی دسکتاپ؛ موبایل سبک است.
- انتقال‌ها فقط روی transform/opacity؛ بارگذاری تنبل تصاویر پایین‌صفحه؛ فونت Vazirmatn + Inter با preconnect.

## در حال انتظار (Pending configuration)

- به‌روزرسانی `canonical`/`og:image` URLها در صورت تغییر دامنهٔ نهایی لندینگ.
- افزودن شمارهٔ تماس/ایمیل پشتیبانی به فوتر در صورت دریافت از کارن‌سافت.
- اتصال آنالیتیکس در صورت تعیین سرویس.
