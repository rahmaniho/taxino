import { useEffect, useRef } from "react";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import TrustStrip from "./components/TrustStrip";
import Challenges from "./components/Challenges";
import Features from "./components/Features";
import Showcase from "./components/Showcase";
import Workflow from "./components/Workflow";
import Compare from "./components/Compare";
import Benefits from "./components/Benefits";
import Pricing from "./components/Pricing";
import Faq from "./components/Faq";
import FinalCta from "./components/FinalCta";
import Footer from "./components/Footer";

/* Thin golden route that fills as the journey progresses down the page */
function RouteProgress() {
  const bar = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const h = document.documentElement;
        const max = h.scrollHeight - h.clientHeight;
        const p = max > 0 ? h.scrollTop / max : 0;
        if (bar.current) bar.current.style.transform = `scaleX(${p})`;
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);
  return (
    <div
      ref={bar}
      aria-hidden="true"
      className="fixed inset-x-0 top-0 z-[60] h-[2px] origin-right bg-gradient-to-l from-gold-2 via-gold to-gold/40"
      style={{ transform: "scaleX(0)" }}
    />
  );
}

export default function App() {
  return (
    <div className="bg-ink text-cream">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:z-[70] focus:m-4 focus:rounded-xl focus:bg-gold focus:px-5 focus:py-3 focus:text-[#171307] focus:font-bold"
      >
        پرش به محتوای اصلی
      </a>
      <RouteProgress />
      <Nav />
      <main id="main">
        <Hero />
        <TrustStrip />
        <Challenges />
        <Features />
        <Showcase />
        <Workflow />
        <Compare />
        <Benefits />
        <Pricing />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
    </div>
  );
}
