import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export const prefersReducedMotion = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export const isTouchDevice = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(pointer: coarse)").matches;

export { gsap, ScrollTrigger };

/**
 * Scroll-triggered reveal. Attach `data-reveal` to children (or use the
 * element itself with `self`). Elements start hidden via gsap.set so SSR-free
 * CSR is safe; reduced-motion users get immediate visibility.
 */
export function useReveal<T extends HTMLElement>(options?: {
  selector?: string;
  y?: number;
  stagger?: number;
  start?: string;
}) {
  const ref = useRef<T>(null);
  const { selector = "[data-reveal]", y = 36, stagger = 0.09, start = "top 84%" } = options || {};
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReducedMotion()) return;
    const targets = Array.from(el.querySelectorAll(selector));
    if (!targets.length) return;
    const ctx = gsap.context(() => {
      gsap.set(targets, { autoAlpha: 0, y });
      ScrollTrigger.create({
        trigger: el,
        start,
        once: true,
        onEnter: () =>
          gsap.to(targets, {
            autoAlpha: 1,
            y: 0,
            duration: 0.9,
            stagger,
            ease: "power3.out",
            overwrite: "auto",
          }),
      });
    }, el);
    return () => ctx.revert();
  }, [selector, y, stagger, start]);
  return ref;
}
