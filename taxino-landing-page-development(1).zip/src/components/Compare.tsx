import { FileText, Minus, Check } from "lucide-react";
import { comparison } from "../data/content";
import { SectionHead } from "./ui";
import { useReveal } from "../lib/anim";

export default function Compare() {
  const ref = useReveal<HTMLElement>({ stagger: 0.07 });
  return (
    <section ref={ref} className="relative overflow-hidden bg-ink py-24 md:py-32" aria-label="مقایسه">
      <div className="mx-auto max-w-[80rem] px-5 md:px-8">
        <SectionHead eyebrow={comparison.eyebrow} title={comparison.title} sub={comparison.sub} align="center" />

        <div className="mx-auto mt-14 max-w-5xl overflow-hidden rounded-[22px] border border-white/[0.08]" data-reveal>
          {/* head row */}
          <div className="grid grid-cols-2 md:grid-cols-[1.1fr_1fr_1.15fr] border-b border-white/[0.08] text-[12.5px] font-extrabold">
            <div className="hidden bg-panel px-6 py-4 text-dim md:block">بُعد عملیاتی</div>
            <div className="bg-rose/[0.04] px-6 py-4 text-silver">مدیریت دستیِ سنتی</div>
            <div className="border-r border-gold/25 bg-gold/[0.07] px-6 py-4 text-gold-2">با تاکسینو</div>
          </div>
          {comparison.rows.map((r) => (
            <div
              key={r.dim}
              data-reveal
              className="grid grid-cols-1 gap-3 border-b border-white/[0.05] px-5 py-5 last:border-0 md:grid-cols-[1.1fr_1fr_1.15fr] md:items-center md:gap-0 md:px-0 md:py-0"
            >
              <div className="flex items-center gap-3 text-[13.5px] font-extrabold text-cream md:bg-panel/60 md:px-6 md:py-5">
                <FileText className="h-4 w-4 shrink-0 text-dim" />
                {r.dim}
              </div>
              <div className="flex items-start gap-2.5 rounded-xl bg-rose/[0.05] p-3.5 text-[12.5px] leading-6 text-silver md:m-3 md:rounded-[14px]">
                <Minus className="mt-1 h-3.5 w-3.5 shrink-0 text-rose/70" strokeWidth={3} />
                {r.manual}
              </div>
              <div className="flex items-start gap-2.5 rounded-xl border border-gold/20 bg-gold/[0.06] p-3.5 text-[12.5px] font-semibold leading-6 text-cream/90 md:m-3 md:rounded-[14px]">
                <Check className="mt-1 h-3.5 w-3.5 shrink-0 text-mint" strokeWidth={3} />
                {r.taxino}
              </div>
            </div>
          ))}
        </div>

        <p className="mx-auto mt-6 max-w-2xl text-center text-[11.5px] leading-6 text-dim" data-reveal>
          از ادعای «رقیبان فلان قابلیت را ندارند» پرهیز می‌کنیم — این جدول فقط دو روش مدیریت را قیاس می‌کند.
        </p>
      </div>
    </section>
  );
}
