import { useEffect, useRef, useState } from "react";
import {
  LayoutDashboard,
  SquarePlus,
  List,
  Users,
  CarTaxiFront,
  Car,
  BookUser,
  MapPin,
  Landmark,
  DatabaseBackup,
  RefreshCw,
  Settings,
  Search,
  Phone,
  TriangleAlert,
  Printer,
  Globe,
} from "lucide-react";
import { showcase } from "../data/content";
import { SectionHead, DemoTag } from "./ui";
import { useReveal, gsap } from "../lib/anim";
import { cn } from "../utils/cn";

/* ────────────────────────────────────────────────────────────────────── */
/* Reconstruction of the real Taxino UI — exact tokens from the product   */
/* (--panel rgba(17,22,43,.84), --gold #D4AF37, radius 17px, Vazirmatn)   */
/* ────────────────────────────────────────────────────────────────────── */

const sideNav = [
  { id: "dashboard", label: "داشبورد", icon: LayoutDashboard },
  { id: "newtrip", label: "ثبت سفر", icon: SquarePlus },
  { id: "trips", label: "لیست سفرها", icon: List },
  { id: "queue", label: "صف انتظار", icon: Users },
  { id: "drivers", label: "رانندگان", icon: CarTaxiFront },
  { id: "cars", label: "خودروها", icon: Car },
  { id: "subscribers", label: "مشترکین", icon: BookUser },
  { id: "addresses", label: "آدرس‌ها", icon: MapPin },
  { id: "accounting", label: "حسابداری", icon: Landmark },
  { id: "backup", label: "پشتیبان‌گیری", icon: DatabaseBackup },
  { id: "sync", label: "همگام‌سازی و اپراتورها", icon: RefreshCw },
  { id: "settings", label: "تنظیمات", icon: Settings },
];

function Sidebar({ active }: { active: string }) {
  return (
    <aside className="hidden w-52 shrink-0 flex-col border-l border-white/[0.07] bg-[#0a0d1d]/95 p-4 md:flex">
      <div className="flex items-center gap-2.5 border-b border-white/[0.07] pb-4">
        <img src="/assets/brand/taxino-icon.png" alt="" className="h-9 w-9 rounded-lg" />
        <div>
          <p className="flex items-center gap-1.5 text-[13px] font-extrabold text-cream">تاکسینو</p>
          <p className="font-latin text-[8.5px] font-bold tracking-[0.18em] text-gold-2">TAXINO</p>
        </div>
      </div>
      <nav className="mt-4 flex flex-1 flex-col gap-1">
        {sideNav.map((n) => (
          <span
            key={n.id}
            className={cn(
              "flex items-center gap-2.5 rounded-lg px-3 py-2 text-[11px] font-semibold",
              active === n.id
                ? "bg-gradient-to-l from-gold/[0.18] to-gold/[0.06] text-gold-2 shadow-[inset_-2px_0_#D4AF37]"
                : "text-silver/80"
            )}
          >
            <n.icon className={cn("h-3.5 w-3.5", active === n.id ? "text-gold" : "text-dim")} />
            {n.label}
          </span>
        ))}
      </nav>
      <div className="rounded-lg border border-white/[0.07] bg-panel-2 p-3 text-[9.5px] leading-5 text-silver">
        <span className="mr-1 inline-block h-1.5 w-1.5 rounded-full bg-mint" />
        عملیات کاملاً آفلاین روی این دستگاه
      </div>
    </aside>
  );
}

function Topbar({ title, sub }: { title: string; sub: string }) {
  return (
    <div className="flex h-14 items-center gap-3 border-b border-white/[0.07] bg-[#080a19]/80 px-4 md:px-6">
      <div className="flex-1">
        <p className="text-[12.5px] font-extrabold text-cream">{title}</p>
        <p className="text-[9px] text-dim">{sub}</p>
      </div>
      <span className="hidden items-center gap-2 rounded-lg border border-white/[0.07] bg-panel px-2.5 py-1.5 text-[9.5px] text-silver sm:flex">
        <span className="grid h-5 w-5 place-items-center rounded-md bg-gold/15 text-[8.5px] font-bold text-gold">م</span>
        اپراتور نمونه
      </span>
      <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/[0.07] bg-panel text-silver">
        <Search className="h-3.5 w-3.5" />
      </span>
    </div>
  );
}

/* ── Screens ─────────────────────────────────────────────────────────── */

function StatCard({ label, value, tone = "cream", hint }: { label: string; value: string; tone?: string; hint?: string }) {
  const toneCls = tone === "gold" ? "text-gold-2" : tone === "mint" ? "text-mint" : tone === "ember" ? "text-ember" : "text-cream";
  return (
    <div className="rounded-[14px] border border-white/[0.07] bg-panel p-3.5">
      <p className="text-[9.5px] text-dim">{label}</p>
      <p className={cn("num mt-1 text-[17px] font-extrabold", toneCls)}>{value}</p>
      {hint && <p className="mt-0.5 text-[8.5px] text-dim">{hint}</p>}
    </div>
  );
}

function ScreenDashboard() {
  return (
    <div className="space-y-3.5">
      <div className="flex items-center gap-2 rounded-[12px] border border-ember/25 bg-ember/[0.08] px-3.5 py-2.5 text-[10px] text-ember">
        <TriangleAlert className="h-3.5 w-3.5" />
        یادآور: ۵ روز از آخرین پشتیبان‌گیری گذشته است (قابل تنظیم)
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="سفرهای امروز" value="۲۴" hint="+۸ نسبت به دیروز" tone="gold" />
        <StatCard label="درآمد امروز (تومان)" value="۴٬۲۸۰٬۰۰۰" />
        <StatCard label="رانندگان فعال" value="۱۲" tone="mint" />
        <StatCard label="در صف انتظار" value="۳" tone="ember" />
      </div>
      <div className="grid gap-3 lg:grid-cols-5">
        <div className="rounded-[14px] border border-white/[0.07] bg-panel p-4 lg:col-span-3">
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-bold text-cream">سفرهای امروز رانندگان</p>
            <span className="text-[8.5px] text-dim">تعداد · در حال انجام · تکمیل</span>
          </div>
          <ul className="mt-3 space-y-2">
            {[
              { n: "رانندهٔ نمونه ۱۲", v: "۷", p: 88 },
              { n: "رانندهٔ نمونه ۰۸", v: "۵", p: 62 },
              { n: "رانندهٔ نمونه ۴۲", v: "۴", p: 48 },
            ].map((r) => (
              <li key={r.n} className="flex items-center gap-3">
                <span className="w-24 truncate text-[10px] text-silver">{r.n}</span>
                <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/[0.06]">
                  <span className="block h-full rounded-full bg-gradient-to-l from-gold to-gold-2" style={{ width: `${r.p}%` }} />
                </span>
                <span className="num w-5 text-left text-[10px] font-bold text-gold-2">{r.v}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-[14px] border border-white/[0.07] bg-panel p-4 lg:col-span-2">
          <p className="text-[11px] font-bold text-cream">درآمد ۷ روز گذشته</p>
          <svg viewBox="0 0 200 60" className="mt-3 w-full" aria-hidden="true">
            <path d="M0,48 C25,45 35,30 58,33 S95,40 118,26 S160,22 200,10" fill="none" stroke="#D4AF37" strokeWidth="2" />
            <path d="M0,48 C25,45 35,30 58,33 S95,40 118,26 S160,22 200,10 L200,60 L0,60 Z" fill="rgba(212,175,55,0.10)" />
          </svg>
          <div className="mt-2 flex justify-between text-[8.5px] text-dim">
            <span>شنبه</span><span>جمعه</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, active }: { label: string; value: string; active?: boolean }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[9.5px] font-bold text-silver">{label}</span>
      <span
        className={cn(
          "block rounded-[10px] border bg-[#0d1226] px-3 py-2.5 text-[11px]",
          active ? "border-gold/50 text-cream shadow-[0_0_0_3px_rgba(212,175,55,0.10)]" : "border-white/[0.09] text-silver"
        )}
      >
        {value}
      </span>
    </label>
  );
}

function ScreenNewTrip() {
  return (
    <div className="grid gap-4 lg:grid-cols-5">
      <div className="rounded-[14px] border border-white/[0.07] bg-panel p-4 lg:col-span-3">
        <p className="text-[11.5px] font-extrabold text-cream">ثبت سفر جدید</p>
        <p className="mt-0.5 text-[8.5px] text-dim">میان‌بُر: کلید N · کرایه و کمیسیون خودکار محاسبه می‌شود</p>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <Field label="نام مسافر" value="مسافر نمونه" active />
          <Field label="تلفن" value="۰۹۱۲ ··· ····" />
          <Field label="مبدا" value="خیابان ولیعصر، پارک ساعی" />
          <Field label="مقصد" value="پایانهٔ جنوب — ورودی ۲" />
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {["تعرفهٔ شب", "تعطیلات", "رفت‌وبرگشت", "چندمسیره"].map((t) => (
            <span key={t} className="rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1 text-[8.5px] text-silver">{t}</span>
          ))}
        </div>
        <div className="mt-4 flex items-center gap-2.5">
          <span className="inline-flex items-center gap-1.5 rounded-[10px] bg-gradient-to-l from-gold-2 to-gold px-4 py-2.5 text-[10.5px] font-extrabold text-[#171307]">
            <SquarePlus className="h-3.5 w-3.5" />
            ثبت سفر
          </span>
          <span className="text-[9px] text-dim">کرایه: محاسبهٔ خودکار پس از پایان سفر</span>
        </div>
      </div>
      <div className="rounded-[14px] border border-white/[0.07] bg-panel p-4 lg:col-span-2">
        <p className="text-[11.5px] font-extrabold text-cream">آخرین سفرهای مسافر</p>
        <ul className="mt-3 space-y-2">
          {[
            { d: "سه‌شنبه — ساعت 一八", a: "پارک ساعی → پایانه جنوب" },
            { d: "هفتهٔ گذشته", a: "میدان ونک → فرودگاه" },
          ].map((r, i) => (
            <li key={i} className="rounded-[10px] border border-white/[0.06] bg-white/[0.03] px-3 py-2.5">
              <p className="text-[9px] text-dim">{r.d}</p>
              <p className="mt-0.5 text-[10px] text-cream/85">{r.a}</p>
            </li>
          ))}
        </ul>
        <div className="mt-3 flex items-center justify-center gap-1.5 rounded-[10px] border border-gold/25 bg-gold/[0.08] py-2 text-[9.5px] font-bold text-gold-2">
          <RefreshCw className="h-3 w-3" />
          تکرار سفر قبلی
        </div>
      </div>
    </div>
  );
}

function ScreenQueue() {
  const rows = [
    { p: "مسافر نمونه ۱", r: "ونک → فرودگاه", w: "۰۴:۲۳", hot: true },
    { p: "مسافر نمونه ۲", r: "میرداماد → بازار", w: "۰۳:۴۱", hot: false },
    { p: "مسافر نمونه ۳", r: "استاد معین → تهرانسر", w: "۰۲:۵۷", hot: false },
  ];
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between rounded-[12px] border border-ember/25 bg-ember/[0.07] px-3.5 py-2.5 text-[10px] text-ember">
        <span className="flex items-center gap-2"><TriangleAlert className="h-3.5 w-3.5" /> یک سفر بیش از آستانه (۴ دقیقه) معلق است</span>
        <span className="num font-bold">آستانه: ۴:۰۰</span>
      </div>
      {rows.map((r, i) => (
        <div key={i} className="flex flex-wrap items-center gap-3 rounded-[14px] border border-white/[0.07] bg-panel px-4 py-3.5">
          <span className={cn("num grid h-8 w-8 place-items-center rounded-lg border text-[11px] font-extrabold", i === 0 ? "border-gold/40 bg-gold/10 text-gold-2" : "border-white/10 bg-white/[0.04] text-silver")}>
            {["۱", "۲", "۳"][i]}
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-bold text-cream">{r.p}</p>
            <p className="truncate text-[9px] text-dim">{r.r}</p>
          </div>
          <span className={cn("num rounded-md px-2 py-1 text-[9px] font-bold", r.hot ? "bg-ember/15 text-ember" : "bg-white/[0.05] text-silver")}>
            انتظار: {r.w}
          </span>
          <div className="flex gap-1.5">
            <span className="inline-flex items-center gap-1 rounded-lg bg-gradient-to-l from-gold-2 to-gold px-3 py-1.5 text-[9px] font-extrabold text-[#171307]">
              <CarTaxiFront className="h-3 w-3" /> اعزام نفر بعدی
            </span>
            <span className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 text-silver"><Phone className="h-3 w-3" /></span>
          </div>
        </div>
      ))}
    </div>
  );
}

function ScreenDrivers() {
  const rows = [
    { n: "رانندهٔ نمونه ۱۲", c: "شاسی نمونه · ۱۲", s: "در سفر", cls: "text-azure bg-azure/10 border-azure/20", t: "۷" },
    { n: "رانندهٔ نمونه ۴۲", c: "شاسی نمونه · ۹۷", s: "آماده", cls: "text-mint bg-mint/10 border-mint/20", t: "۴" },
    { n: "رانندهٔ نمونه ۰۸", c: "شاسی نمونه · ۳۵", s: "استراحت تا ۱۴:۰۰", cls: "text-ember bg-ember/10 border-ember/20", t: "۵" },
    { n: "رانندهٔ نمونه ۳۰", c: "شاسی نمونه · ۱۱", s: "مرخصی — امروز", cls: "text-silver bg-white/[0.05] border-white/10", t: "۰" },
  ];
  return (
    <div className="space-y-2.5">
      <div className="flex gap-2">
        {["همه", "آماده", "در نوبت", "مرخصی"].map((t, i) => (
          <span key={t} className={cn("rounded-lg border px-3 py-1.5 text-[9.5px] font-bold", i === 0 ? "border-gold/40 bg-gold/10 text-gold-2" : "border-white/[0.08] text-silver")}>{t}</span>
        ))}
      </div>
      {rows.map((r) => (
        <div key={r.n} className="flex flex-wrap items-center gap-3 rounded-[14px] border border-white/[0.07] bg-panel px-4 py-3">
          <span className="grid h-9 w-9 place-items-center rounded-xl border border-white/[0.08] bg-panel-3">
            <CarTaxiFront className="h-4 w-4 text-gold" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-bold text-cream">{r.n}</p>
            <p className="text-[9px] text-dim">{r.c}</p>
          </div>
          <span className={cn("rounded-md border px-2.5 py-1 text-[9px] font-bold", r.cls)}>{r.s}</span>
          <span className="text-[9px] text-dim">امروز: <b className="num text-cream">{r.t}</b> سفر</span>
          <span className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 text-silver"><Phone className="h-3 w-3" /></span>
        </div>
      ))}
    </div>
  );
}

function ScreenSubscribers() {
  const rows = [
    { n: "مشترک حقوقی — نمونه «الف»", type: "حقوقی", bal: "۱٬۲۰۰٬۰۰۰+", tone: "text-mint", tag: "اعتباری" },
    { n: "مشترک حقیقی — نمونه", type: "حقیقی", bal: "۱۸۵٬۰۰۰-", tone: "text-ember", tag: "بدهکار" },
    { n: "سازمان — نمونه", type: "حقوقی", bal: "۰", tone: "text-silver", tag: "تسویه" },
  ];
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 rounded-[10px] border border-white/[0.09] bg-[#0d1226] px-3.5 py-2.5 text-[10px] text-dim">
        <Search className="h-3.5 w-3.5" />
        جست‌وجوی مشترک…
        <span className="font-latin mr-auto rounded border border-white/15 px-1.5 py-0.5 text-[8px]">Ctrl + K</span>
      </div>
      {rows.map((r) => (
        <div key={r.n} className="flex flex-wrap items-center gap-3 rounded-[14px] border border-white/[0.07] bg-panel px-4 py-3.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gold/10 border border-gold/20">
            <BookUser className="h-4 w-4 text-gold-2" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-bold text-cream">{r.n}</p>
            <p className="text-[9px] text-dim">نوع: {r.type}</p>
          </div>
          <div className="text-left">
            <p className={cn("num text-[12px] font-extrabold", r.tone)} dir="ltr">{r.bal}</p>
            <p className="text-[8.5px] text-dim">تومان — {r.tag}</p>
          </div>
          <span className="inline-flex items-center gap-1 rounded-lg border border-white/10 px-2.5 py-1.5 text-[9px] text-silver">
            <Printer className="h-3 w-3" /> صورتحساب
          </span>
        </div>
      ))}
    </div>
  );
}

function ScreenAccounting() {
  const tabs = ["درآمد", "صورتحساب راننده", "سود و زیان", "کمیسیون", "مشترکین", "هزینه‌ها", "دفتر اسناد", "آرشیو"];
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-1.5">
        {tabs.map((t, i) => (
          <span key={t} className={cn("rounded-lg border px-2.5 py-1.5 text-[9px] font-bold", i === 0 ? "border-gold/40 bg-gold/10 text-gold-2" : "border-white/[0.08] bg-white/[0.02] text-silver")}>{t}</span>
        ))}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {["امروز", "۷ روز", "۳۰ روز", "این ماه", "سال", "دلخواه"].map((t, i) => (
          <span key={t} className={cn("rounded-md px-2.5 py-1 text-[8.5px]", i === 2 ? "bg-white/[0.09] font-bold text-cream" : "text-dim")}>{t}</span>
        ))}
        <span className="num mr-auto text-[8.5px] text-dim">۱ مهر ۱۴۰۴ تا ۳۱ مهر ۱۴۰۴</span>
      </div>
      <div className="grid grid-cols-3 gap-2.5">
        <StatCard label="درآمد ناخالص" value="۳۸٬۴۶۰٬۰۰۰" />
        <StatCard label="کمیسیون آژانس" value="۵٬۷۷۰٬۰۰۰" tone="gold" />
        <StatCard label="هزینه‌ها" value="۱٬۹۲۰٬۰۰۰" tone="ember" />
      </div>
      <div className="rounded-[14px] border border-white/[0.07] bg-panel p-4">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-bold text-cream">دفتر اسناد — شماره‌گذاری متوالی</p>
          <span className="inline-flex items-center gap-1.5 text-[8.5px] text-dim"><Printer className="h-3 w-3" /> چاپ مجدد</span>
        </div>
        <ul className="mt-3 space-y-1.5">
          {[
            { id: "سند-۱۴۸۲", t: "تسویهٔ گروهی رانندگان (۱۲ نفر)", v: "۹٬۸۴۰٬۰۰۰" },
            { id: "سند-۱۴۸۱", t: "صورتحساب مشترک — نمونه «الف»", v: "۱٬۲۰۰٬۰۰۰" },
            { id: "سند-۱۴۸۰", t: "رسید سفر — پایانه جنوب", v: "۱۸۵٬۰۰۰" },
          ].map((r) => (
            <li key={r.id} className="flex items-center justify-between rounded-[10px] border border-white/[0.05] bg-white/[0.025] px-3.5 py-2.5">
              <span className="num text-[9px] font-bold text-gold-2">{r.id}</span>
              <span className="min-w-0 flex-1 truncate px-3 text-[10px] text-silver">{r.t}</span>
              <span className="num text-[10px] font-bold text-cream">{r.v}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

const screens: Record<string, { head: [string, string]; el: () => React.ReactNode }> = {
  dashboard: { head: ["داشبورد", "نمای کلی عملیات امروز آژانس"], el: ScreenDashboard },
  newtrip: { head: ["ثبت سفر جدید", "ثبت سریع با محاسبهٔ خودکار کرایه"], el: ScreenNewTrip },
  queue: { head: ["صف انتظار", "نظارت بر انتظار و اعزام نوبتی"], el: ScreenQueue },
  drivers: { head: ["رانندگان", "وضعیت، نوبت و عملکرد روزانه"], el: ScreenDrivers },
  subscribers: { head: ["مشترکین", "حساب‌های اعتباری و مانده‌ها"], el: ScreenSubscribers },
  accounting: { head: ["حسابداری", "۸ بخش با بازهٔ تاریخ شمسی"], el: ScreenAccounting },
};

/* ── Section ─────────────────────────────────────────────────────────── */
export default function Showcase() {
  const secRef = useReveal<HTMLElement>();
  const [tab, setTab] = useState("dashboard");
  const bodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!bodyRef.current) return;
    gsap.fromTo(
      bodyRef.current,
      { autoAlpha: 0, y: 14 },
      { autoAlpha: 1, y: 0, duration: 0.45, ease: "power2.out" }
    );
  }, [tab]);

  const screen = screens[tab] || screens.dashboard;
  const ScreenEl = screen.el;

  return (
    <section
      ref={secRef}
      id="showcase"
      className="map-grid relative overflow-hidden bg-ink py-24 md:py-32"
      aria-label="محیط واقعی برنامه"
    >
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-[460px] opacity-70"
        style={{ background: "radial-gradient(60% 100% at 50% 0%, rgba(11,25,66,0.5), transparent)" }}
      />
      <div className="relative mx-auto max-w-[80rem] px-5 md:px-8">
        <SectionHead
          eyebrow={showcase.eyebrow}
          title={showcase.title}
          sub={showcase.sub}
          align="center"
        />

        {/* tab chips */}
        <div className="mt-12 flex flex-wrap justify-center gap-2" role="tablist" aria-label="بخش‌های برنامه" data-reveal>
          {showcase.tabs.map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "rounded-xl border px-4 py-2.5 text-[12.5px] font-bold transition-all duration-300 md:px-5",
                tab === t.id
                  ? "border-gold/50 bg-gold/12 text-gold-2 shadow-[0_8px_26px_rgba(212,175,55,0.15)]"
                  : "border-white/[0.09] bg-white/[0.02] text-silver hover:border-white/20 hover:text-cream"
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* browser frame */}
        <div className="mt-8 overflow-hidden rounded-[20px] border border-white/[0.09] bg-[#0a0d1d] shadow-[0_50px_120px_rgba(0,0,0,0.5)]" data-reveal>
          {/* chrome bar */}
          <div className="flex items-center gap-3 border-b border-white/[0.07] bg-[#0d1128] px-4 py-3">
            <div className="flex gap-1.5" aria-hidden="true">
              <span className="h-2.5 w-2.5 rounded-full bg-[#3a4166]" />
              <span className="h-2.5 w-2.5 rounded-full bg-[#3a4166]" />
              <span className="h-2.5 w-2.5 rounded-full bg-gold/70" />
            </div>
            <div className="mx-auto flex w-full max-w-sm items-center justify-center gap-2 rounded-lg border border-white/[0.07] bg-[#080a19] px-4 py-1.5 text-[10.5px] text-silver">
              <Globe className="h-3 w-3 text-mint" />
              <span className="font-latin" dir="ltr">taxi.karen-soft.ir</span>
            </div>
            <span className="num hidden rounded-md border border-white/10 px-1.5 py-0.5 text-[9px] text-dim sm:block">v1.6.0</span>
          </div>

          {/* app shell */}
          <div className="flex min-h-[480px]">
            <Sidebar active={tab === "newtrip" ? "newtrip" : tab} />
            <div className="min-w-0 flex-1">
              <Topbar title={screen.head[0]} sub={screen.head[1]} />
              <div ref={bodyRef} className="p-4 md:p-6">
                <ScreenEl />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 flex flex-col items-center gap-3 text-center">
          <DemoTag />
          <p className="max-w-2xl text-[12.5px] leading-7 text-dim" data-reveal>
            {showcase.note}
          </p>
        </div>
      </div>
    </section>
  );
}
