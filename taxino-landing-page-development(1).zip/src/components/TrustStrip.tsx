import { ShieldCheck, HardDrive, Cloud, Smartphone } from "lucide-react";
import { trust } from "../data/content";
import { useReveal } from "../lib/anim";

const icons = [ShieldCheck, HardDrive, Cloud, Smartphone];

export default function TrustStrip() {
  const ref = useReveal<HTMLDivElement>();
  return (
    <section className="relative border-y border-white/[0.06] bg-[#0a0d20]" aria-label="اعتماد و اعتبار">
      <div ref={ref} className="mx-auto max-w-[80rem] px-5 py-16 md:px-8">
        <div className="flex flex-col items-start justify-between gap-8 lg:flex-row lg:items-center">
          <div className="max-w-xl">
            <h2 className="text-[19px] md:text-[22px] font-extrabold leading-9 text-cream" data-reveal>
              {trust.title}
            </h2>
            <p className="mt-3 flex flex-wrap items-center gap-2 text-[13px] leading-7 text-silver" data-reveal>
              {trust.sub.split("—")[0]}
              <span className="num rounded-md border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[10.5px] text-gold-2">
                v1.6.0
              </span>
            </p>
          </div>
          <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {trust.points.map((p, i) => {
              const Icon = icons[i];
              return (
                <li key={p} className="flex items-center gap-3 text-[13px] text-cream/85" data-reveal>
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-gold/25 bg-gold/10 text-gold-2">
                    <Icon className="h-4 w-4" />
                  </span>
                  {p}
                </li>
              );
            })}
          </ul>
        </div>

        {/* capability marquee */}
        <div className="marquee-mask relative mt-14 overflow-hidden" data-reveal aria-hidden="true">
          <div className="marquee-track flex w-max gap-3" style={{ direction: "ltr" }}>
            {[...trust.marquee, ...trust.marquee].map((m, i) => (
              <span
                key={i}
                className="flex items-center gap-2.5 whitespace-nowrap rounded-full border border-white/[0.07] bg-white/[0.025] px-5 py-2.5 text-[12.5px] font-semibold text-silver"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-gold/70" />
                {m}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
