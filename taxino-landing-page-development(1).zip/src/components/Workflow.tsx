import { useEffect, useRef } from "react";
import { workflow } from "../data/content";
import { SectionHead } from "./ui";
import { gsap, prefersReducedMotion } from "../lib/anim";

/* Six stations on one continuous golden route — desktop: vertical spine,
   animated stroke that draws as you scroll, stations ignite in sequence. */
export default function Workflow() {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = root.current;
    if (!el || prefersReducedMotion()) return;
    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(el);

      gsap.fromTo(
        q(".wf-line-fill"),
        { scaleY: 0 },
        {
          scaleY: 1,
          ease: "none",
          transformOrigin: "top",
          scrollTrigger: { trigger: q(".wf-track")[0], start: "top 72%", end: "bottom 55%", scrub: 0.6 },
        }
      );

      q(".wf-step").forEach((step) => {
        const panel = step.querySelector(".wf-card");
        const node = step.querySelector(".wf-node");
        gsap.set(panel, { autoAlpha: 0, y: 34, scale: 0.97 });
        gsap.set(node, { scale: 0, transformOrigin: "center" });
        gsap
          .timeline({
            scrollTrigger: { trigger: step, start: "top 76%", once: true },
          })
          .to(node, { scale: 1, duration: 0.55, ease: "back.out(2.4)" })
          .to(panel, { autoAlpha: 1, y: 0, scale: 1, duration: 0.8, ease: "power3.out" }, 0.12);
      });
    }, el);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={root} id="workflow" className="relative overflow-hidden bg-abyss py-24 md:py-32" aria-label="نحوهٔ عملکرد تاکسینو">
      <div className="pointer-events-none absolute inset-0 opacity-50" style={{ background: "radial-gradient(800px 500px at 12% 30%, rgba(11,25,66,0.5), transparent)" }} />
      <div className="relative mx-auto max-w-[80rem] px-5 md:px-8">
        <SectionHead eyebrow={workflow.eyebrow} title={workflow.title} sub={workflow.sub} align="center" className="mb-16" />

        <div className="wf-track relative mx-auto max-w-4xl">
          {/* spine */}
          <div className="absolute right-[27.5px] top-2 bottom-2 w-px bg-white/[0.07] md:right-1/2 md:translate-x-px" aria-hidden="true" />
          <div className="wf-line-fill absolute right-[27px] top-2 bottom-2 w-[2px] bg-gradient-to-b from-gold-2 via-gold to-gold/30 md:right-1/2 md:translate-x-px" aria-hidden="true" />

          <ol className="space-y-12 md:space-y-16">
            {workflow.steps.map((s, i) => {
              const leftSide = i % 2 === 0; // content side alternates on desktop
              return (
                <li key={s.n} className="wf-step relative md:grid md:grid-cols-2 md:items-center md:gap-14">
                  {/* node */}
                  <span
                    className="wf-node absolute right-2.5 top-1 z-10 grid h-9 w-9 place-items-center rounded-full border-2 border-gold-2 bg-ink shadow-[0_0_24px_rgba(240,207,100,0.35)] md:right-1/2 md:translate-x-1/2"
                    aria-hidden="true"
                  >
                    <span className="num text-[11px] font-extrabold text-gold-2">{s.n}</span>
                  </span>

                  {/* content */}
                  <div className={`pr-14 md:pr-0 ${leftSide ? "md:col-start-1 md:flex md:justify-end" : "md:col-start-2"}`}>
                    <div className="wf-card panel group w-full max-w-md border-white/[0.07] p-6 transition-all duration-400 hover:border-gold/30 hover:shadow-[0_20px_60px_rgba(212,175,55,0.08)] md:p-7">
                      <h3 className="flex items-center gap-3 text-[17px] font-extrabold text-cream">
                        <span className="h-px w-6 bg-gold/50 transition-all duration-300 group-hover:w-9" />
                        {s.title}
                      </h3>
                      <p className="mt-3 text-[13.5px] leading-7.5 text-silver">{s.desc}</p>
                    </div>
                  </div>

                  {/* ghost latin index on the opposite side */}
                  <span
                    aria-hidden="true"
                    className={`font-latin pointer-events-none hidden select-none text-[52px] font-extrabold text-white/[0.05] md:block ${leftSide ? "md:col-start-2" : "md:col-start-1 md:row-start-1 md:text-left"}`}
                  >
                    STATION {i + 1}
                  </span>
                </li>
              );
            })}
          </ol>

          {/* destination flag */}
          <div className="mt-14 flex justify-center" aria-hidden="true">
            <span className="relative flex items-center gap-2 rounded-full border border-gold/30 bg-gold/[0.08] px-5 py-2 text-[11.5px] font-bold text-gold-2">
              <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-gold-2" />
              سفر با موفقیت تسویه شد
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
