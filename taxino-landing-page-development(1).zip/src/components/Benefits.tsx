import { ListChecks, Search, RefreshCw, Scale, Zap, DatabaseBackup } from "lucide-react";
import { benefits } from "../data/content";
import { SectionHead } from "./ui";
import { useReveal } from "../lib/anim";
import { cn } from "../utils/cn";

const icons = [ListChecks, Search, RefreshCw, Scale, Zap, DatabaseBackup];

export default function Benefits() {
  const ref = useReveal<HTMLElement>({ stagger: 0.08 });
  return (
    <section ref={ref} className="relative overflow-hidden bg-abyss py-24 md:py-32" aria-label="مزایای کسب‌وکار">
      <div
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{ background: "radial-gradient(760px 460px at 88% 100%, rgba(11,25,66,0.55), transparent)" }}
      />
      <div className="relative mx-auto max-w-[80rem] px-5 md:px-8">
        <SectionHead eyebrow={benefits.eyebrow} title={benefits.title} sub={benefits.sub} />

        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.items.map((b, i) => {
            const Icon = icons[i];
            return (
              <article
                key={b.title}
                data-reveal
                className={cn(
                  "group relative overflow-hidden rounded-[20px] border border-white/[0.07] bg-gradient-to-b from-panel to-[#0d1128] p-7 transition-all duration-500",
                  "hover:-translate-y-1.5 hover:border-gold/30 hover:shadow-[0_28px_70px_rgba(0,0,0,0.45)]"
                )}
              >
                <div
                  className="pointer-events-none absolute -top-10 -left-10 h-36 w-36 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100"
                  style={{ background: "radial-gradient(closest-side, rgba(212,175,55,0.16), transparent)" }}
                />
                <div className="flex items-center justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl border border-gold/20 bg-gold/[0.08] text-gold-2 transition-transform duration-500 group-hover:rotate-[8deg] group-hover:scale-110">
                    <Icon className="h-5.5 w-5.5" strokeWidth={1.9} />
                  </span>
                  <span className="num text-[11px] font-bold text-white/15 transition-colors duration-500 group-hover:text-gold/40">
                    {String(i + 1).padStart(2, "0").replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d])}
                  </span>
                </div>
                <h3 className="mt-5 text-[16.5px] font-extrabold text-cream">{b.title}</h3>
                <p className="mt-2.5 text-[13px] leading-7 text-silver">{b.desc}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
