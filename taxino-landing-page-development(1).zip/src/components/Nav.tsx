import { useEffect, useState } from "react";
import { Menu, X, ArrowLeft } from "lucide-react";
import { APP_URL, nav } from "../data/content";
import { cn } from "../utils/cn";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const sections = nav
      .map((n) => document.getElementById(n.id))
      .filter((el): el is HTMLElement => !!el);
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-38% 0px -55% 0px" }
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled
            ? "bg-ink/82 backdrop-blur-xl border-b border-white/[0.06] shadow-[0_10px_40px_rgba(0,0,0,0.35)]"
            : "bg-transparent border-b border-transparent"
        )}
      >
        <div className="mx-auto flex h-[72px] max-w-[80rem] items-center justify-between gap-4 px-5 md:px-8">
          {/* Brand */}
          <a href="#top" className="flex items-center gap-3 group" aria-label="تاکسینو — صفحه اصلی">
            <img
              src="/assets/brand/taxino-icon.png"
              alt="لوگوی تاکسینو"
              width={40}
              height={40}
              className="h-10 w-10 rounded-xl shadow-[0_8px_22px_rgba(0,0,0,0.4)] transition-transform duration-300 group-hover:scale-[1.05]"
            />
            <span className="flex flex-col leading-none">
              <span className="text-[17px] font-extrabold text-cream tracking-tight">تاکسینو</span>
              <span className="font-latin text-[10px] font-bold text-gold-2 tracking-[0.22em] mt-1">
                TAXINO
              </span>
            </span>
          </a>

          {/* Desktop links */}
          <nav className="hidden lg:flex items-center gap-1" aria-label="ناوبری اصلی">
            {nav.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className={cn(
                  "relative px-4 py-2 text-[13.5px] font-semibold rounded-lg transition-colors duration-300",
                  active === item.id ? "text-gold-2" : "text-silver hover:text-cream"
                )}
              >
                {item.label}
                <span
                  className={cn(
                    "absolute inset-x-4 -bottom-0.5 h-px bg-gradient-to-l from-transparent via-gold to-transparent transition-opacity duration-300",
                    active === item.id ? "opacity-100" : "opacity-0"
                  )}
                />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href={APP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-sheen hidden sm:inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-gold-2 to-gold px-5 py-2.5 text-[13px] font-bold text-[#171307] shadow-[0_10px_28px_rgba(212,175,55,0.22)] transition-transform duration-300 hover:-translate-y-0.5"
            >
              شروع استفاده
              <ArrowLeft className="h-4 w-4" strokeWidth={2.5} />
            </a>
            <button
              onClick={() => setOpen(!open)}
              className="lg:hidden inline-flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-cream"
              aria-expanded={open}
              aria-label={open ? "بستن منو" : "باز کردن منو"}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className={cn(
          "fixed inset-0 z-40 lg:hidden transition-opacity duration-300",
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
      >
        <div className="absolute inset-0 bg-abyss/80 backdrop-blur-sm" onClick={() => setOpen(false)} />
        <div
          className={cn(
            "absolute inset-x-4 top-24 panel-deep p-6 transition-all duration-400",
            open ? "translate-y-0 opacity-100" : "-translate-y-4 opacity-0"
          )}
        >
          <nav className="flex flex-col gap-1" aria-label="ناوبری موبایل">
            {nav.map((item, i) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={() => setOpen(false)}
                className="flex items-center justify-between rounded-xl px-4 py-3.5 text-[15px] font-bold text-cream transition-colors hover:bg-white/[0.05] hover:text-gold-2"
                style={{ transitionDelay: `${i * 30}ms` }}
              >
                {item.label}
                <ArrowLeft className="h-4 w-4 text-dim" />
              </a>
            ))}
            <a
              href={APP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-gold-2 to-gold px-5 py-3.5 text-[14px] font-bold text-[#171307]"
            >
              شروع استفاده
              <ArrowLeft className="h-4 w-4" strokeWidth={2.5} />
            </a>
          </nav>
        </div>
      </div>
    </>
  );
}
