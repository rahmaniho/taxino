import { useState } from "react";
import { Plus } from "lucide-react";
import { faq } from "../data/content";
import { SectionHead } from "./ui";
import { useReveal } from "../lib/anim";
import { cn } from "../utils/cn";

export default function Faq() {
  const ref = useReveal<HTMLElement>();
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section ref={ref} id="faq" className="relative bg-abyss py-24 md:py-32" aria-label="سوالات متداول">
      <div className="mx-auto max-w-[80rem] px-5 md:px-8">
        <div className="grid gap-14 lg:grid-cols-[1fr_1.5fr]">
          <div className="lg:sticky lg:top-32 self-start">
            <SectionHead eyebrow={faq.eyebrow} title={faq.title} sub="پاسخ‌ها بر اساس رفتار واقعی نرم‌افزار نوشته شده‌اند." />
          </div>

          <ol className="flex flex-col gap-3">
            {faq.items.map((f, i) => {
              const isOpen = open === i;
              return (
                <li
                  key={f.q}
                  data-reveal
                  className={cn(
                    "overflow-hidden rounded-[18px] border transition-colors duration-400",
                    isOpen ? "panel border-gold/30" : "border-white/[0.07] bg-white/[0.02] hover:border-white/[0.14]"
                  )}
                >
                  <button
                    onClick={() => setOpen(isOpen ? null : i)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between gap-4 px-6 py-5 text-right"
                  >
                    <span className={cn("text-[14.5px] font-extrabold transition-colors", isOpen ? "text-gold-2" : "text-cream")}>
                      {f.q}
                    </span>
                    <span
                      className={cn(
                        "grid h-8 w-8 shrink-0 place-items-center rounded-full border transition-all duration-400",
                        isOpen
                          ? "rotate-45 border-gold/40 bg-gold/12 text-gold-2"
                          : "border-white/12 text-silver"
                      )}
                    >
                      <Plus className="h-4 w-4" />
                    </span>
                  </button>
                  <div
                    className="grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]"
                    style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                  >
                    <div className="overflow-hidden">
                      <p className="px-6 pb-6 text-[13.5px] leading-8 text-silver">{f.a}</p>
                    </div>
                  </div>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}
