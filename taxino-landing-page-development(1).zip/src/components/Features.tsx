import {
  Route,
  RefreshCw,
  BookUser,
  Landmark,
  MessagesSquare,
  ShieldCheck,
  Check,
  Phone,
  Share2,
  Lock,
} from "lucide-react";
import { featureGroups, type FeatureGroup } from "../data/content";
import { useReveal } from "../lib/anim";
import { DemoTag } from "./ui";
import { cn } from "../utils/cn";

const groupIcons = [Route, RefreshCw, BookUser, Landmark, MessagesSquare, ShieldCheck];

/* ── Signature mini-visuals (pure SVG/CSS, product-token accurate) ────── */

function TripsVisual() {
  const states = ["ثبت‌شده", "تخصیص‌یافته", "در حال انجام", "تکمیل"];
  return (
    <div className="panel w-full max-w-md p-6">
      <div className="flex items-center justify-between text-[11px] text-dim">
        <span>گردش‌کار سفر</span>
        <DemoTag />
      </div>
      <div className="relative mt-5">
        <div className="absolute right-[7px] top-2 bottom-2 w-px bg-gradient-to-b from-gold/60 via-gold/25 to-mint/50" />
        <ol className="space-y-4">
          {states.map((s, i) => (
            <li key={s} className="relative flex items-center gap-4 pr-0">
              <span
                className={cn(
                  "z-10 grid h-4 w-4 place-items-center rounded-full border-2",
                  i === 3
                    ? "border-mint bg-mint/20"
                    : i === 0
                      ? "border-gold-2 bg-gold/25"
                      : "border-gold/50 bg-panel"
                )}
              />
              <span
                className={cn(
                  "flex-1 rounded-xl border px-4 py-2.5 text-[12.5px] font-bold",
                  i === 0
                    ? "border-gold/30 bg-gold/10 text-gold-2"
                    : i === 3
                      ? "border-mint/25 bg-mint/[0.08] text-mint"
                      : "border-white/[0.07] bg-white/[0.03] text-silver"
                )}
              >
                {s}
              </span>
              <span className="num text-[10px] text-dim">
                {["۱۲:۰۴", "۱۲:۰۶", "۱۲:۰۹", "۱۲:۲۶"][i]}
              </span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}

function DriversVisual() {
  return (
    <div className="panel w-full max-w-md p-6">
      <div className="flex items-center justify-between text-[11px] text-dim">
        <span>دیسپچ نوبتی</span>
        <DemoTag />
      </div>
      <div className="relative mx-auto mt-6 h-44 w-44">
        <svg viewBox="0 0 176 176" className="h-full w-full">
          <circle cx="88" cy="88" r="72" fill="none" stroke="rgba(255,255,255,0.08)" strokeDasharray="4 7" />
          <circle cx="88" cy="88" r="72" fill="none" stroke="#D4AF37" strokeOpacity="0.7" strokeDasharray="70 384" strokeLinecap="round" transform="rotate(-90 88 88)" />
          {[...Array(8)].map((_, i) => {
            const a = (i / 8) * Math.PI * 2 - Math.PI / 2;
            const x = 88 + 72 * Math.cos(a);
            const y = 88 + 72 * Math.sin(a);
            return (
              <g key={i}>
                <circle cx={x} cy={y} r={i === 0 ? 11 : 8} fill={i === 0 ? "#F0CF64" : "#191F3B"} stroke={i === 0 ? "#F0CF64" : "rgba(255,255,255,0.14)"} />
                {i === 0 && <circle cx={x} cy={y} r="4" fill="#171307" />}
              </g>
            );
          })}
        </svg>
        <div className="absolute inset-0 grid place-items-center">
          <div className="text-center">
            <p className="text-[10px] text-dim">نفر بعدی</p>
            <p className="mt-1 text-[13px] font-extrabold text-gold-2">رانندهٔ ۴۲</p>
          </div>
        </div>
      </div>
      <div className="mt-4 flex justify-center gap-2">
        <span className="rounded-md border border-mint/25 bg-mint/10 px-2.5 py-1 text-[10px] font-bold text-mint">آماده</span>
        <span className="rounded-md border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10px] text-silver">استراحت</span>
        <span className="rounded-md border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10px] text-silver">مرخصی</span>
      </div>
    </div>
  );
}

function SubscribersVisual() {
  const rows = [
    { n: "مشترک حقوقی — نمونه", r: "اعتباری", v: "۱٬۲۰۰٬۰۰۰+", c: "text-mint" },
    { n: "مشترک حقیقی — نمونه", r: "مانده بدهی", v: "۱۸۵٬۰۰۰", c: "text-ember" },
    { n: "مشترک سازمانی — نمونه", r: "تسویه‌شده", v: "۰", c: "text-silver" },
  ];
  return (
    <div className="panel w-full max-w-md p-6">
      <div className="flex items-center justify-between text-[11px] text-dim">
        <span>حساب اعتباری مشترکین</span>
        <DemoTag />
      </div>
      <ul className="mt-4 space-y-2.5">
        {rows.map((r) => (
          <li key={r.n} className="flex items-center justify-between gap-3 rounded-xl border border-white/[0.07] bg-white/[0.03] px-4 py-3">
            <div className="flex items-center gap-3">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-gold/10 text-gold-2">
                <BookUser className="h-4 w-4" />
              </span>
              <div>
                <p className="text-[12px] font-bold text-cream">{r.n}</p>
                <p className="text-[10px] text-dim">{r.r}</p>
              </div>
            </div>
            <span className={cn("num text-[12px] font-bold", r.c)}>{r.v}</span>
          </li>
        ))}
      </ul>
      <div className="mt-4 rounded-xl border border-white/[0.07] bg-gradient-to-l from-gold/10 to-transparent px-4 py-3 text-center text-[10.5px] text-silver">
        صورتحساب قابل چاپ با لوگوی آژانس
      </div>
    </div>
  );
}

function AccountingVisual() {
  const bars = [34, 58, 42, 71, 50, 88, 64];
  return (
    <div className="panel w-full max-w-md p-6">
      <div className="flex items-center justify-between text-[11px] text-dim">
        <span>درآمد هفتگی — بازهٔ شمسی</span>
        <DemoTag />
      </div>
      <div className="mt-5 flex h-32 items-end gap-2.5 px-1">
        {bars.map((h, i) => (
          <div key={i} className="flex flex-1 flex-col items-center gap-2">
            <div
              className={cn(
                "w-full rounded-t-md transition-all duration-500",
                i === 5
                  ? "bg-gradient-to-t from-gold to-gold-2 shadow-[0_0_20px_rgba(212,175,55,0.35)]"
                  : "bg-white/[0.09]"
              )}
              style={{ height: `${h}%` }}
            />
            <span className="text-[9px] text-dim">{["ش", "ی", "د", "س", "چ", "پ", "ج"][i]}</span>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-between rounded-xl border border-white/[0.07] bg-white/[0.03] px-4 py-2.5 text-[11px]">
        <span className="text-silver">سود و زیان · کمیسیون · تسویهٔ گروهی</span>
        <span className="num font-bold text-gold-2">۸ تب</span>
      </div>
    </div>
  );
}

function CommsVisual() {
  return (
    <div className="panel w-full max-w-md p-6">
      <div className="flex items-center justify-between text-[11px] text-dim">
        <span>الگوی پیامک تخصیص</span>
        <DemoTag />
      </div>
      <div className="mt-4 space-y-3">
        <div className="max-w-[85%] rounded-2xl rounded-tr-sm border border-gold/25 bg-gold/[0.09] px-4 py-3 text-[12px] leading-6 text-cream/90">
          «مسافر گرامی، خودروی شما تخصیص یافت. پلاک: — · راننده در مسیر است.»
        </div>
        <div className="mr-auto max-w-[70%] rounded-2xl rounded-tl-sm border border-white/[0.08] bg-white/[0.04] px-4 py-3 text-[12px] text-silver">
          آمادهٔ حرکت هستید؟ راننده در ۵ دقیقه می‌رسد.
        </div>
      </div>
      <div className="mt-4 flex items-center gap-2">
        {[
          { icon: Phone, t: "تماس مستقیم" },
          { icon: MessagesSquare, t: "۳ الگوی پیامکی" },
          { icon: Share2, t: "اشتراک سفر" },
        ].map((x) => (
          <span key={x.t} className="flex items-center gap-1.5 rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-1.5 text-[10.5px] text-silver">
            <x.icon className="h-3.5 w-3.5 text-gold" />
            {x.t}
          </span>
        ))}
      </div>
    </div>
  );
}

function InfraVisual() {
  return (
    <div className="panel w-full max-w-md p-6">
      <div className="flex items-center justify-between text-[11px] text-dim">
        <span>امنیت و پشتیبان‌گیری</span>
      </div>
      <div className="mt-5 grid grid-cols-2 gap-3">
        <div className="rounded-xl border border-white/[0.07] bg-white/[0.03] p-4 text-center">
          <ShieldCheck className="mx-auto h-6 w-6 text-mint" />
          <p className="mt-2 text-[11px] font-bold text-cream">پشتیبان رمزنگاری‌شده</p>
          <p className="mt-1 font-latin text-[9px] tracking-wider text-dim">AES-GCM 256</p>
        </div>
        <div className="rounded-xl border border-white/[0.07] bg-white/[0.03] p-4 text-center">
          <Lock className="mx-auto h-6 w-6 text-gold-2" />
          <p className="mt-2 text-[11px] font-bold text-cream">قفل PIN اپراتورها</p>
          <p className="mt-1 text-[9px] text-dim">مدیر · حسابدار · اپراتور</p>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-center gap-3 rounded-xl border border-white/[0.07] bg-gradient-to-l from-azure/[0.07] to-transparent px-4 py-3">
        <span className="text-[10.5px] text-silver">همگام‌سازی محلی چند پنجره + بستهٔ فایلی بین دستگاه‌ها</span>
        <RefreshCw className="h-4 w-4 shrink-0 text-azure" />
      </div>
    </div>
  );
}

const visuals = [TripsVisual, DriversVisual, SubscribersVisual, AccountingVisual, CommsVisual, InfraVisual];

/* ── Section ─────────────────────────────────────────────────────────── */
export default function Features() {
  const ref = useReveal<HTMLElement>({ stagger: 0.06 });
  return (
    <section ref={ref} id="features" className="relative overflow-hidden bg-abyss py-24 md:py-32" aria-label="امکانات تاکسینو">
      <div className="pointer-events-none absolute inset-0 opacity-60" style={{ background: "radial-gradient(900px 480px at 85% 0%, rgba(11,25,66,0.55), transparent)" }} />
      <div className="relative mx-auto max-w-[80rem] px-5 md:px-8">
        <div className="mb-20 max-w-3xl">
          <div className="flex items-center gap-3" data-reveal>
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute h-full w-full animate-pulse-dot rounded-full bg-gold-2" />
              <span className="relative h-2.5 w-2.5 rounded-full bg-gold-2" />
            </span>
            <span className="h-px w-10 bg-gradient-to-l from-gold/70 to-transparent" />
            <span className="text-[13px] font-bold text-gold-2">امکانات اصلی</span>
          </div>
          <h2 className="h-display mt-5 text-[clamp(1.9rem,3.6vw,3.1rem)] text-cream" data-reveal>
            یک سامانه، شش ستونِ عملیات آژانس
          </h2>
          <p className="mt-4 text-[15px] leading-8 text-silver" data-reveal>
            هر ستون دقیقاً همان چیزی است که داخل نرم‌افزار وجود دارد — بدون وعدهٔ اغراق‌آمیز.
          </p>
        </div>

        <div className="space-y-24 md:space-y-32">
          {featureGroups.map((g: FeatureGroup, i) => {
            const Icon = groupIcons[i];
            const Visual = visuals[i];
            const flip = i % 2 === 1;
            return (
              <article key={g.id} className="relative grid items-center gap-12 lg:grid-cols-2" aria-label={g.title}>
                {/* ghost index */}
                <span
                  aria-hidden="true"
                  className={cn(
                    "font-latin pointer-events-none absolute -top-14 select-none text-[130px] font-extrabold leading-none text-transparent md:text-[170px]",
                    flip ? "left-0" : "right-0"
                  )}
                  style={{ WebkitTextStroke: "1px rgba(212,175,55,0.13)" }}
                >
                  {String(i + 1).padStart(2, "0")}
                </span>

                <div className={cn("relative", flip && "lg:order-2")}>
                  <div className="flex items-center gap-4" data-reveal>
                    <span className="grid h-13 w-13 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-gold/20 to-gold/5 border border-gold/25 text-gold-2 shadow-[0_10px_30px_rgba(212,175,55,0.12)]">
                      <Icon className="h-6 w-6" strokeWidth={1.9} />
                    </span>
                    <div>
                      <p className="font-latin text-[10px] font-bold tracking-[0.3em] text-dim">{g.latin}</p>
                      <h3 className="mt-1 text-[22px] md:text-[27px] font-extrabold text-cream">{g.title}</h3>
                    </div>
                    <span className="num mr-auto text-[13px] font-bold text-dim">{g.index} / ۰۶</span>
                  </div>
                  <p className="mt-3 text-[14px] font-bold text-gold-2/90" data-reveal>{g.tagline}</p>
                  <p className="mt-3 max-w-xl text-[14.5px] leading-8 text-silver" data-reveal>{g.desc}</p>
                  <ul className="mt-6 space-y-3.5">
                    {g.points.map((p) => (
                      <li key={p} className="flex items-start gap-3 text-[13.5px] leading-7 text-cream/85" data-reveal>
                        <span className="mt-1.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-gold/12 border border-gold/25">
                          <Check className="h-3 w-3 text-gold-2" strokeWidth={3} />
                        </span>
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className={cn("flex", flip ? "lg:order-1 lg:justify-start" : "lg:justify-end")} data-reveal>
                  <Visual />
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
