import { useLayoutEffect, useRef } from "react";
import {
  BellRing,
  Users,
  UserCheck,
  Banknote,
  Eye,
  ArrowLeft,
  MapPin,
} from "lucide-react";
import { gsap, prefersReducedMotion, isTouchDevice } from "../lib/anim";
import { APP_URL, hero, sceneCards } from "../data/content";
import { DemoTag } from "./ui";

/* ── Floating product panels (coded UI, matching the real app's tokens) ── */
function TripCard() {
  const c = sceneCards.trip;
  return (
    <div className="panel w-[264px] p-4 shadow-[0_24px_60px_rgba(0,0,0,0.45)]" data-depth="26">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-gold-2 text-[11px] font-bold">
          <BellRing className="h-3.5 w-3.5" />
          {c.title}
        </div>
        <span className="text-[10px] text-dim">{c.time}</span>
      </div>
      <div className="mt-3 flex items-start gap-2.5">
        <MapPin className="h-4 w-4 text-gold mt-0.5 shrink-0" />
        <p className="text-[12px] leading-6 text-cream/90">{c.meta}</p>
      </div>
      <div className="mt-3 flex gap-2">
        <span className="rounded-lg bg-gold/15 border border-gold/30 text-gold-2 text-[10.5px] font-bold px-3 py-1.5">
          تخصیص نفر بعدی
        </span>
        <span className="rounded-lg border border-white/10 text-silver text-[10.5px] px-3 py-1.5">
          جزئیات سفر
        </span>
      </div>
    </div>
  );
}

function QueueCard() {
  const c = sceneCards.queue;
  return (
    <div className="panel w-[248px] p-4 shadow-[0_24px_60px_rgba(0,0,0,0.45)]" data-depth="34">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-cream text-[11.5px] font-bold">
          <Users className="h-3.5 w-3.5 text-gold" />
          {c.title}
        </div>
        <span className="chip-live flex items-center text-[10px] text-mint font-bold gap-1.5">
          {c.count}
        </span>
      </div>
      <ul className="mt-3 space-y-2">
        {c.rows.map((r) => (
          <li
            key={r.a}
            className="flex items-center justify-between rounded-lg border border-white/[0.06] bg-white/[0.03] px-3 py-2"
          >
            <span className="text-[11px] text-cream/85">{r.a}</span>
            <span className="num text-[10px] text-ember font-semibold">{r.t}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function DriverCard() {
  const c = sceneCards.driver;
  return (
    <div className="panel w-[232px] p-4 shadow-[0_24px_60px_rgba(0,0,0,0.45)]" data-depth="20">
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-panel-3 to-navy border border-white/10 grid place-items-center">
            <UserCheck className="h-5 w-5 text-gold-2" />
          </div>
          <span className="absolute -bottom-0.5 -left-0.5 h-3 w-3 rounded-full bg-mint border-2 border-[#0d1226]" />
        </div>
        <div>
          <p className="text-[12px] font-bold text-cream">{c.name}</p>
          <p className="num text-[10px] text-dim mt-0.5">{c.plate}</p>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between rounded-lg bg-mint/10 border border-mint/20 px-3 py-2">
        <span className="text-[10.5px] font-bold text-mint">{c.state}</span>
        <span className="text-[9px] text-dim">در نوبت اعزام</span>
      </div>
    </div>
  );
}

function RevenueCard() {
  const c = sceneCards.revenue;
  return (
    <div className="panel w-[236px] p-4 shadow-[0_24px_60px_rgba(0,0,0,0.45)]" data-depth="40">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-cream text-[11.5px] font-bold">
          <Banknote className="h-3.5 w-3.5 text-gold" />
          {c.title}
        </div>
        <span className="text-[9.5px] text-dim">{c.trend}</span>
      </div>
      <div className="mt-2.5 flex items-baseline gap-1.5">
        <span className="num text-[21px] font-extrabold text-gold-grad">{c.amount}</span>
        <span className="text-[10px] text-silver">{c.unit}</span>
      </div>
      <svg viewBox="0 0 200 44" className="mt-2 w-full" aria-hidden="true">
        <defs>
          <linearGradient id="spark" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#D4AF37" stopOpacity="0.35" />
            <stop offset="1" stopColor="#F0CF64" />
          </linearGradient>
          <linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#D4AF37" stopOpacity="0.25" />
            <stop offset="1" stopColor="#D4AF37" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d="M0,36 C22,34 30,24 50,26 S84,30 104,20 S144,16 162,10 S192,6 200,4 L200,44 L0,44 Z" fill="url(#sparkFill)" />
        <path d="M0,36 C22,34 30,24 50,26 S84,30 104,20 S144,16 162,10 S192,6 200,4" fill="none" stroke="url(#spark)" strokeWidth="2" />
        <circle cx="200" cy="4" r="3" fill="#F0CF64" className="animate-pulse-dot" />
      </svg>
    </div>
  );
}

/* ── Hero ─────────────────────────────────────────────────────────────── */
export default function Hero() {
  const root = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const el = root.current;
    if (!el) return;
    if (prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(el);

      /* pre-paint hidden states for the line masks */
      gsap.set(q(".lmask > span"), { yPercent: 112 });

      /* Cinematic intro timeline */
      const tl = gsap.timeline({
        defaults: { ease: "power3.out" },
        delay: 0.15,
      });

      tl.to(q(".hero-shade"), { autoAlpha: 0, duration: 1.15, ease: "power2.inOut" }, 0)
        /* city emerges */
        .fromTo(
          q(".hero-bg"),
          { scale: 1.14, autoAlpha: 0 },
          { scale: 1, autoAlpha: 1, duration: 2.1, ease: "power2.out" },
          0.1
        )
        /* golden route ignites */
        .fromTo(
          q(".route-path"),
          { strokeDashoffset: 1 },
          { strokeDashoffset: 0, duration: 1.5, ease: "power2.inOut" },
          0.75
        )
        .fromTo(
          q(".route-node"),
          { scale: 0, autoAlpha: 0, transformOrigin: "center" },
          { scale: 1, autoAlpha: 1, duration: 0.5, stagger: 0.22, ease: "back.out(2.2)" },
          1.05
        )
        /* headlight sweep — the vehicle enters */
        .fromTo(
          q(".hero-sweep"),
          { xPercent: -140, autoAlpha: 0 },
          { xPercent: 60, autoAlpha: 1, duration: 1.3, ease: "power2.inOut" },
          0.65
        )
        .to(q(".hero-sweep"), { autoAlpha: 0, duration: 0.8 }, 1.95)
        /* floating panels emerge */
        .fromTo(
          q(".hero-panel"),
          { y: 54, autoAlpha: 0, rotateX: -14 },
          { y: 0, autoAlpha: 1, rotateX: 0, duration: 0.95, stagger: 0.12 },
          1.35
        )
        /* typography */
        .to(q(".hero-eyebrow"), { autoAlpha: 1, y: 0, duration: 0.7 }, 1.1)
        .to(
          q(".lmask > span"),
          { yPercent: 0, duration: 1.05, stagger: 0.13, ease: "power4.out" },
          1.35
        )
        .to(q(".hero-sub"), { autoAlpha: 1, y: 0, duration: 0.8 }, 1.85)
        .to(q(".hero-ctas"), { autoAlpha: 1, y: 0, duration: 0.8 }, 2.05)
        .to(q(".hero-strip"), { autoAlpha: 1, duration: 0.9 }, 2.3);

      /* scroll parallax */
      gsap.to(q(".hero-bg"), {
        yPercent: 16,
        scale: 1.05,
        ease: "none",
        scrollTrigger: { trigger: el, start: "top top", end: "bottom top", scrub: true },
      });
      gsap.to(q(".hero-content"), {
        yPercent: -10,
        autoAlpha: 0.25,
        ease: "none",
        scrollTrigger: { trigger: el, start: "top top", end: "72% top", scrub: true },
      });

      /* pointer depth (desktop, fine pointers only) */
      if (!isTouchDevice()) {
        const px = gsap.quickTo(q(".hero-scene")[0], "x", { duration: 1.1, ease: "power3.out" });
        const py = gsap.quickTo(q(".hero-scene")[0], "y", { duration: 1.1, ease: "power3.out" });
        const onMove = (e: PointerEvent) => {
          const r = el.getBoundingClientRect();
          px(((e.clientX - r.left) / r.width - 0.5) * -18);
          py(((e.clientY - r.top) / r.height - 0.5) * -12);
        };
        el.addEventListener("pointermove", onMove, { passive: true });
        return () => el.removeEventListener("pointermove", onMove);
      }
    }, el);

    return () => ctx.revert();
  }, []);

  const rm = typeof window !== "undefined" && prefersReducedMotion();

  return (
    <section
      ref={root}
      id="top"
      className="grain relative min-h-[100svh] overflow-hidden bg-abyss"
      aria-label="معرفی تاکسینو"
    >
      {/* cinematic shade that lifts on load */}
      {!rm && <div className="hero-shade absolute inset-0 z-40 bg-abyss" aria-hidden="true" />}

      {/* ── Scene ── */}
      <div className="hero-scene absolute inset-0 will-change-transform" aria-hidden="true">
        <img
          src="/assets/img/hero-city.jpg"
          alt=""
          className="hero-bg absolute inset-0 h-full w-full object-cover opacity-80"
          fetchPriority="high"
          draggable={false}
        />
        {/* atmosphere */}
        <div className="absolute inset-0 bg-gradient-to-l from-abyss/92 via-ink/35 to-navy/25" />
        <div className="absolute inset-x-0 bottom-0 h-[46%] bg-gradient-to-t from-ink via-ink/55 to-transparent" />
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-ink/85 to-transparent" />
        <div
          className="absolute -top-24 left-[8%] h-[420px] w-[560px] rounded-full opacity-60 blur-3xl"
          style={{ background: "radial-gradient(closest-side, rgba(212,175,55,0.14), transparent)" }}
        />

        {/* golden route */}
        <svg
          viewBox="0 0 1440 830"
          preserveAspectRatio="xMidYMid slice"
          className="absolute inset-0 h-full w-full"
        >
          <defs>
            <linearGradient id="routeGold" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#F0CF64" stopOpacity="0.15" />
              <stop offset="0.45" stopColor="#F0CF64" />
              <stop offset="1" stopColor="#D4AF37" />
            </linearGradient>
          </defs>
          <path
            className="route-path"
            d="M150,235 C340,160 540,240 690,330 C830,415 905,428 1012,470 C1130,516 1228,566 1306,648"
            fill="none"
            stroke="url(#routeGold)"
            strokeWidth="2.5"
            strokeLinecap="round"
            pathLength={1}
            strokeDasharray={1}
          />
          <g className="route-node">
            <circle cx="150" cy="235" r="5" fill="#F0CF64" />
            <circle cx="150" cy="235" r="12" fill="none" stroke="#F0CF64" strokeOpacity="0.35" />
          </g>
          <g className="route-node">
            <circle cx="690" cy="330" r="4" fill="#0B1942" stroke="#F0CF64" strokeWidth="2" />
          </g>
          <g className="route-node">
            <circle cx="1012" cy="470" r="4" fill="#0B1942" stroke="#F0CF64" strokeWidth="2" />
          </g>
          <g className="route-node">
            <circle cx="1306" cy="648" r="6.5" fill="#F0CF64" />
            <circle cx="1306" cy="648" r="17" fill="none" stroke="#F0CF64" strokeOpacity="0.4" className="animate-pulse-dot" style={{ transformOrigin: "1306px 648px" }} />
          </g>
        </svg>

        {/* headlight sweep */}
        <div
          className="hero-sweep absolute bottom-[6%] left-0 h-[46%] w-[42%] opacity-0 mix-blend-screen"
          style={{
            background:
              "linear-gradient(100deg, transparent 10%, rgba(240,207,100,0.16) 45%, rgba(253,180,0,0.05) 75%, transparent)",
            filter: "blur(6px)",
          }}
        />
      </div>

      {/* ── Floating panels (desktop) ── */}
      <div className="absolute inset-0 hidden lg:block" aria-hidden="true">
        <div className="hero-panel absolute left-[5%] top-[19%] animate-float-y" style={{ animationDelay: "0.2s" }}>
          <TripCard />
        </div>
        <div className="hero-panel absolute left-[23%] top-[47%] animate-float-y" style={{ animationDelay: "1.4s" }}>
          <QueueCard />
        </div>
        <div className="hero-panel absolute left-[6.5%] top-[63%] animate-float-y" style={{ animationDelay: "0.8s" }}>
          <RevenueCard />
        </div>
        <div className="hero-panel absolute left-[30%] top-[20.5%] animate-float-y" style={{ animationDelay: "2s" }}>
          <DriverCard />
        </div>
        <div className="hero-panel absolute bottom-[13%] left-[10%]">
          <DemoTag />
        </div>
      </div>

      {/* ── Content ── */}
      <div className="hero-content relative z-20 mx-auto flex min-h-[100svh] w-full max-w-[80rem] flex-col justify-center px-5 pb-32 pt-36 md:px-8 lg:pt-24">
        <div className="max-w-2xl">
          <div
            className="hero-eyebrow flex items-center gap-3 opacity-0"
            style={rm ? { opacity: 1 } : undefined}
          >
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute h-full w-full animate-pulse-dot rounded-full bg-gold-2" />
              <span className="relative h-2.5 w-2.5 rounded-full bg-gold-2" />
            </span>
            <span className="h-px w-12 bg-gradient-to-l from-gold to-transparent" />
            <span className="text-[13px] font-bold text-gold-2">{hero.eyebrow}</span>
          </div>

          <h1 className="h-display mt-7 text-[clamp(2.6rem,6vw,5.1rem)] text-cream">
            <span className="lmask">
              <span>{hero.titleA}</span>
            </span>
            <span className="lmask">
              <span className="text-gold-grad">{hero.titleB}</span>
            </span>
            <span className="lmask">
              <span>{hero.titleC}</span>
            </span>
          </h1>

          <p
            className="hero-sub mt-6 max-w-xl text-[15.5px] leading-8 text-silver md:text-[17px] md:leading-9 opacity-0"
            style={rm ? { opacity: 1 } : undefined}
          >
            {hero.sub}
          </p>

          <div
            className="hero-ctas mt-10 flex flex-wrap items-center gap-4 opacity-0"
            style={rm ? { opacity: 1 } : undefined}
          >
            <a
              href={APP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-sheen group inline-flex items-center gap-2.5 rounded-2xl bg-gradient-to-l from-gold-2 via-gold to-gold-2 bg-[length:200%_100%] bg-[position:100%] px-7 py-4 text-[15px] font-extrabold text-[#171307] shadow-[0_18px_45px_rgba(212,175,55,0.28)] transition-all duration-400 hover:bg-[position:0%] hover:-translate-y-1 hover:shadow-[0_24px_60px_rgba(212,175,55,0.38)]"
            >
              {hero.ctaPrimary}
              <ArrowLeft className="h-[18px] w-[18px] transition-transform duration-300 group-hover:-translate-x-1" strokeWidth={2.6} />
            </a>
            <a
              href="#features"
              className="inline-flex items-center gap-2.5 rounded-2xl border border-white/12 bg-white/[0.05] px-7 py-4 text-[15px] font-bold text-cream backdrop-blur-md transition-all duration-300 hover:border-gold/45 hover:bg-white/[0.08] hover:text-gold-2"
            >
              <Eye className="h-[18px] w-[18px] text-gold" />
              {hero.ctaSecondary}
            </a>
          </div>

          <p className="mt-5 text-[11px] text-dim lg:hidden">{hero.demoNote}</p>
        </div>
      </div>

      {/* ── Bottom signature strip ── */}
      <div
        className="hero-strip absolute inset-x-0 bottom-0 z-20 opacity-0"
        style={rm ? { opacity: 1 } : undefined}
      >
        <div className="mx-auto flex max-w-[80rem] flex-wrap items-center justify-between gap-4 border-t border-white/[0.07] px-5 py-5 md:px-8">
          <div className="flex items-center gap-3">
            <span className="font-latin text-[13px] font-extrabold tracking-[0.3em] text-gold-2">
              {hero.signatureEn}
            </span>
            <span className="h-3.5 w-px bg-white/15" />
            <span className="text-[12px] text-silver">{hero.poweredBy}</span>
            <span className="font-latin text-[11px] text-dim">{hero.poweredByEn}</span>
          </div>
          <div className="hidden items-center gap-2 md:flex" aria-label="ویژگی‌های سریع">
            {["عملکرد آفلاین", "نصب PWA", "نسخهٔ ۱٫۶"].map((t) => (
              <span
                key={t}
                className="rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-[11px] font-semibold text-silver"
              >
                {t}
              </span>
            ))}
          </div>
          <div className="flex items-center gap-2 text-dim" aria-hidden="true">
            <span className="text-[10.5px]">اسکرول کنید</span>
            <span className="block h-8 w-px overflow-hidden bg-white/10">
              <span className="block h-3 w-px animate-[float-y_1.6s_ease-in-out_infinite] bg-gold-2" />
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
