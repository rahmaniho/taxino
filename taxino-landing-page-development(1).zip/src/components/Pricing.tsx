import { Check, MessagesSquare, Rocket, Clock, Infinity as InfinityIcon, ShieldCheck } from "lucide-react";
import { APP_URL, pricing } from "../data/content";
import { SectionHead } from "./ui";
import { useReveal } from "../lib/anim";

export default function Pricing() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} id="pricing" className="relative overflow-hidden bg-ink py-24 md:py-32" aria-label="اشتراک و قیمت‌گذاری">
      <div
        className="pointer-events-none absolute top-10 left-1/2 h-[440px] w-[840px] -translate-x-1/2 rounded-full opacity-60 blur-3xl"
        style={{ background: "radial-gradient(closest-side, rgba(212,175,55,0.08), transparent)" }}
      />
      <div className="relative mx-auto max-w-[80rem] px-5 md:px-8">
        <SectionHead eyebrow={pricing.eyebrow} title={pricing.title} sub={pricing.sub} align="center" />

        {/* licenses line */}
        <div className="mx-auto mt-10 flex max-w-2xl items-center justify-center gap-3" data-reveal>
          <span className="flex items-center gap-2 rounded-full border border-white/[0.09] bg-white/[0.03] px-5 py-2.5 text-[12.5px] font-bold text-silver">
            <Clock className="h-4 w-4 text-gold" /> لایسنس زمان‌دار
          </span>
          <span className="h-px w-8 bg-white/10" />
          <span className="flex items-center gap-2 rounded-full border border-gold/30 bg-gold/[0.08] px-5 py-2.5 text-[12.5px] font-bold text-gold-2">
            <InfinityIcon className="h-4 w-4" /> لایسنس مادام‌العمر
          </span>
        </div>

        <div className="mx-auto mt-12 max-w-3xl" data-reveal>
          <div className="rounded-[24px] bg-gradient-to-b from-gold/50 via-gold/15 to-white/[0.06] p-px shadow-[0_40px_100px_rgba(212,175,55,0.10)]">
            <div className="rounded-[23px] bg-gradient-to-b from-[#131936] to-[#0a0d20] p-8 md:p-11">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <h3 className="flex items-center gap-3 text-[19px] font-extrabold text-cream">
                  <ShieldCheck className="h-6 w-6 text-gold-2" />
                  {pricing.includesTitle}
                </h3>
                <span className="rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-[10.5px] text-dim">
                  قیمت‌ها به‌روز و رسمی — فقط از کارشناسان
                </span>
              </div>

              <ul className="mt-7 grid gap-3.5 sm:grid-cols-2">
                {pricing.includes.map((it) => (
                  <li key={it} className="flex items-start gap-2.5 text-[13px] leading-7 text-cream/85">
                    <span className="mt-1.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border border-mint/30 bg-mint/10">
                      <Check className="h-3 w-3 text-mint" strokeWidth={3} />
                    </span>
                    {it}
                  </li>
                ))}
              </ul>

              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <a
                  href="#contact"
                  className="btn-sheen inline-flex flex-1 items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-l from-gold-2 to-gold px-6 py-4 text-[14.5px] font-extrabold text-[#171307] shadow-[0_14px_40px_rgba(212,175,55,0.25)] transition-transform duration-300 hover:-translate-y-0.5"
                >
                  <MessagesSquare className="h-[18px] w-[18px]" />
                  {pricing.ctaConsult}
                </a>
                <a
                  href={APP_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex flex-1 items-center justify-center gap-2.5 rounded-2xl border border-white/12 bg-white/[0.04] px-6 py-4 text-[14.5px] font-bold text-cream transition-colors duration-300 hover:border-gold/40 hover:text-gold-2"
                >
                  <Rocket className="h-[18px] w-[18px] text-gold" />
                  {pricing.ctaStart}
                </a>
              </div>
              <p className="mt-5 text-center text-[11px] text-dim">{pricing.note}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
