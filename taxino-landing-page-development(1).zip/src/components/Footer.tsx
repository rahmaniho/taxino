import { ArrowUp, ExternalLink } from "lucide-react";
import { APP_URL, footer } from "../data/content";

export default function Footer() {
  return (
    <footer className="border-t border-white/[0.06] bg-abyss" aria-label="پانوشت">
      <div className="mx-auto max-w-[80rem] px-5 py-16 md:px-8">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr]">
          {/* brand */}
          <div>
            <div className="flex items-center gap-3">
              <img src="/assets/brand/taxino-icon.png" alt="لوگوی تاکسینو" className="h-12 w-12 rounded-xl" width={48} height={48} />
              <div>
                <p className="text-[17px] font-extrabold text-cream">تاکسینو</p>
                <p className="font-latin text-[10px] font-bold tracking-[0.24em] text-gold-2">TAXINO</p>
              </div>
            </div>
            <p className="mt-5 max-w-sm text-[13px] leading-7.5 text-silver">{footer.about}</p>
            <div className="mt-5 flex flex-wrap gap-2">
              {["نسخهٔ ۱٫۶٫۰", "PWA", "آفلاین‌محور"].map((t) => (
                <span key={t} className="rounded-md border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 text-[10px] font-semibold text-dim">
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* link columns */}
          {footer.columns.map((col) => (
            <nav key={col.title} aria-label={col.title}>
              <h3 className="text-[12px] font-extrabold tracking-wide text-dim">{col.title}</h3>
              <ul className="mt-5 space-y-3.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      {...(l.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                      className="group inline-flex items-center gap-2 text-[13.5px] font-semibold text-silver transition-colors hover:text-gold-2"
                    >
                      {l.label}
                      {l.external && <ExternalLink className="h-3 w-3 text-dim transition-colors group-hover:text-gold-2" />}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-5 border-t border-white/[0.06] pt-7 md:flex-row">
          <p className="text-[12px] text-dim">{footer.copyright}</p>
          <a
            href={APP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="font-latin text-[12px] font-bold tracking-wide text-silver transition-colors hover:text-gold-2"
            dir="ltr"
          >
            {footer.madeBy}
          </a>
          <a
            href="#top"
            className="inline-flex items-center gap-2 rounded-xl border border-white/[0.09] bg-white/[0.03] px-4 py-2 text-[12px] font-semibold text-silver transition-colors hover:border-gold/40 hover:text-gold-2"
            aria-label="بازگشت به بالای صفحه"
          >
            <ArrowUp className="h-3.5 w-3.5" />
            بازگشت به بالا
          </a>
        </div>
      </div>
    </footer>
  );
}
