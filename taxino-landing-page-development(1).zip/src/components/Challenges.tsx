import { ClipboardX, UserX, FolderOpen, BookUser, EyeOff, Route } from "lucide-react";
import { challenges } from "../data/content";
import { useReveal } from "../lib/anim";
import { SectionHead } from "./ui";

const icons = [ClipboardX, UserX, FolderOpen, BookUser, EyeOff];

export default function Challenges() {
  const ref = useReveal<HTMLElement>({ stagger: 0.08 });
  return (
    <section ref={ref} className="map-grid relative overflow-hidden bg-ink py-24 md:py-32" aria-label="چالش‌های عملیاتی">
      <div
        className="pointer-events-none absolute top-0 left-1/2 h-[380px] w-[720px] -translate-x-1/2 rounded-full opacity-50 blur-3xl"
        style={{ background: "radial-gradient(closest-side, rgba(241,120,131,0.05), transparent)" }}
      />
      <div className="relative mx-auto max-w-[80rem] px-5 md:px-8">
        <div className="grid gap-14 lg:grid-cols-[1fr_1.35fr]">
          <div className="lg:sticky lg:top-32 self-start">
            <SectionHead
              eyebrow={challenges.eyebrow}
              title={challenges.title}
              sub={challenges.sub}
            />
          </div>

          <ol className="flex flex-col">
            {challenges.items.map((c, i) => {
              const Icon = icons[i];
              return (
                <li
                  key={c.title}
                  data-reveal
                  className="group flex items-start gap-5 border-b border-white/[0.06] py-7 first:border-t transition-colors duration-300 hover:border-rose/20"
                >
                  <span className="num mt-1 text-[13px] font-bold text-dim group-hover:text-rose transition-colors">
                    {String(i + 1).padStart(2, "0").replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d])}
                  </span>
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-rose/15 bg-rose/[0.07] text-rose/90 transition-transform duration-300 group-hover:scale-105">
                    <Icon className="h-5 w-5" strokeWidth={1.8} />
                  </span>
                  <div>
                    <h3 className="text-[16.5px] font-extrabold text-cream">{c.title}</h3>
                    <p className="mt-1.5 max-w-lg text-[13.5px] leading-7 text-silver">{c.desc}</p>
                  </div>
                </li>
              );
            })}
          </ol>
        </div>

        {/* transformation band */}
        <div
          data-reveal
          className="relative mt-16 overflow-hidden rounded-[22px] border border-gold/20 bg-gradient-to-l from-gold/[0.09] via-[#141a36] to-panel p-8 md:p-11"
        >
          <div
            className="pointer-events-none absolute -top-16 right-10 h-56 w-56 rounded-full blur-3xl"
            style={{ background: "radial-gradient(closest-side, rgba(212,175,55,0.22), transparent)" }}
          />
          <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center">
            <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-gold-2 to-gold text-[#171307] shadow-[0_14px_34px_rgba(212,175,55,0.3)]">
              <Route className="h-7 w-7" strokeWidth={2.2} />
            </span>
            <div>
              <h3 className="text-[19px] md:text-[23px] font-extrabold leading-9 text-cream">
                {challenges.shift.title}
              </h3>
              <p className="mt-2 max-w-3xl text-[14px] leading-8 text-silver">{challenges.shift.desc}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
