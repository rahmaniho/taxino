import { ArrowLeft, Headset, Rocket, Wrench } from "lucide-react";
import { APP_URL, ISSUES_URL, finalCta } from "../data/content";
import { useReveal } from "../lib/anim";

export default function FinalCta() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} id="contact" className="relative bg-ink px-5 pb-24 pt-8 md:px-8 md:pb-32" aria-label="شروع با تاکسینو">
      <div className="relative mx-auto max-w-[80rem] overflow-hidden rounded-[28px] border border-gold/20 shadow-[0_60px_140px_rgba(0,0,0,0.55)]" data-reveal>
        {/* cinematic backdrop */}
        <img
          src="/assets/img/cta-car.jpg"
          alt="خودروی لوکس آژانس در شب بارانی شهر با نورهای طلایی"
          className="absolute inset-0 h-full w-full scale-105 object-cover object-center"
          loading="lazy"
          draggable={false}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#05070f]/97 via-[#080a19]/72 to-[#080a19]/35" />
        <div
          className="pointer-events-none absolute -bottom-20 left-1/2 h-64 w-[640px] -translate-x-1/2 rounded-full opacity-70 blur-3xl"
          style={{ background: "radial-gradient(closest-side, rgba(212,175,55,0.2), transparent)" }}
        />

        <div className="relative flex flex-col items-center px-6 py-20 text-center md:py-28">
          <img
            src="/assets/brand/taxino-icon.png"
            alt=""
            className="h-16 w-16 rounded-2xl shadow-[0_18px_44px_rgba(0,0,0,0.5)]"
            data-reveal
          />
          <h2 className="h-display mt-8 max-w-3xl text-[clamp(1.8rem,3.8vw,3.2rem)] text-cream" data-reveal>
            {finalCta.title}
          </h2>
          <p className="mt-5 max-w-2xl text-[15px] leading-8 text-cream/75" data-reveal>
            {finalCta.sub}
          </p>

          <div className="mt-10 flex w-full max-w-lg flex-col gap-3.5 sm:flex-row" data-reveal>
            <a
              href={APP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-sheen group inline-flex flex-1 items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-l from-gold-2 to-gold px-7 py-4.5 text-[15px] font-extrabold text-[#171307] shadow-[0_20px_55px_rgba(212,175,55,0.35)] transition-all duration-300 hover:-translate-y-1"
            >
              <Rocket className="h-5 w-5" />
              {finalCta.primary}
              <ArrowLeft className="h-[18px] w-[18px] transition-transform duration-300 group-hover:-translate-x-1" strokeWidth={2.5} />
            </a>
            <a
              href={ISSUES_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex flex-1 items-center justify-center gap-2.5 rounded-2xl border border-white/15 bg-white/[0.06] px-7 py-4.5 text-[15px] font-bold text-cream backdrop-blur-md transition-colors duration-300 hover:border-gold/45 hover:text-gold-2"
            >
              <Headset className="h-5 w-5 text-gold" />
              {finalCta.secondary}
            </a>
          </div>

          <p className="mt-7 flex items-center gap-2 text-[11.5px] text-cream/50" data-reveal>
            <Wrench className="h-3.5 w-3.5" />
            مسیر رسمی پشتیبانی: پنل اشتراک داخل سامانه + صفحهٔ Issues مخزن پروژه در گیت‌هاب
          </p>
        </div>
      </div>
    </section>
  );
}
