import { cn } from "../utils/cn";

/* Eyebrow with the signature "route node" glyph */
export function SectionHead({
  eyebrow,
  title,
  sub,
  align = "start",
  className,
}: {
  eyebrow: string;
  title: string;
  sub?: string;
  align?: "start" | "center";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-5 max-w-3xl",
        align === "center" && "items-center text-center mx-auto",
        className
      )}
    >
      <div className="flex items-center gap-3" data-reveal>
        <span className="relative flex h-2.5 w-2.5">
          <span className="absolute inline-flex h-full w-full rounded-full bg-gold-2 opacity-60 animate-pulse-dot" />
          <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-gold-2" />
        </span>
        <span className="h-px w-10 bg-gradient-to-l from-gold/70 to-transparent" />
        <span className="text-gold-2 text-[13px] font-bold tracking-tight">{eyebrow}</span>
      </div>
      <h2 className="h-display text-cream text-[clamp(1.9rem,3.6vw,3.1rem)]" data-reveal>
        {title}
      </h2>
      {sub && (
        <p className="text-silver text-[15px] md:text-base leading-8" data-reveal>
          {sub}
        </p>
      )}
    </div>
  );
}

/* Clearly-labelled demo-data tag used on illustrative figures */
export function DemoTag({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10px] font-semibold text-silver",
        className
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-amber/80" />
      دادهٔ نمایشی
    </span>
  );
}

/* Hairline divider with side glyphs */
export function Rule({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-4 text-dim", className)} aria-hidden>
      <span className="h-px flex-1 bg-gradient-to-l from-white/12 to-transparent" />
      <span className="font-latin text-[10px] tracking-[0.35em]">TAXINO</span>
      <span className="h-px flex-1 bg-gradient-to-r from-white/12 to-transparent" />
    </div>
  );
}
